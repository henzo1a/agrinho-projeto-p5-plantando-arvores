// --- VARIÁVEIS DO JOGO ---
let planta; // Objeto que representará nossa planta
let estadoJogo = "inicio"; // Pode ser "inicio", "jogando", "morto", "floresceu"

// Variáveis para os controles de água, luz e nutrientes
let sliderAgua;
let sliderLuz;
let sliderNutrientes;

// --- CLASSES ---
// Classe para representar nossa planta
class Planta {
  constructor() {
    this.x = width / 2;
    this.y = height - 50; // Posição inicial no solo
    this.altura = 5; // Altura inicial da planta (começa pequena)
    this.larguraBase = 10; // Largura da base do tronco
    this.corTronco = color(100, 70, 40); // Marrom
    this.corFolhas = color(50, 150, 50); // Verde
    this.corFlores = color(255, 100, 200); // Rosa (quando florescer)
    this.floresceu = false;
    this.saude = 100; // Saúde da planta (0 a 100)
    this.tempoCrescimento = 0; // Tempo acumulado de crescimento
    this.tempoMaxCrescimento = 1000; // Tempo necessário para florescer
  }

  // Desenha a planta na tela
  display() {
    // Tronco
    fill(this.corTronco);
    noStroke();
    rect(this.x - this.larguraBase / 2, this.y - this.altura, this.larguraBase, this.altura);

    // Folhas (simples, como triângulos)
    if (this.altura > 20) { // Começa a ter folhas a partir de certa altura
      fill(this.corFolhas);
      let numFolhas = map(this.altura, 20, height - 100, 1, 5); // Mais folhas conforme cresce
      for (let i = 0; i < numFolhas; i++) {
        let yFolha = this.y - this.altura * (0.3 + i * 0.15);
        triangle(
          this.x, yFolha,
          this.x - this.larguraBase * 1.5, yFolha + this.larguraBase,
          this.x - this.larguraBase * 0.5, yFolha - this.larguraBase / 2
        );
        triangle(
          this.x, yFolha,
          this.x + this.larguraBase * 1.5, yFolha + this.larguraBase,
          this.x + this.larguraBase * 0.5, yFolha - this.larguraBase / 2
        );
      }
    }

    // Flores (se floresceu)
    if (this.floresceu) {
      fill(this.corFlores);
      ellipse(this.x, this.y - this.altura - 10, 20, 20); // Uma flor no topo
      // Pequenos círculos para pétalas
      for (let i = 0; i < 6; i++) {
        let angle = TWO_PI / 6 * i;
        ellipse(this.x + cos(angle) * 15, this.y - this.altura - 10 + sin(angle) * 15, 10, 10);
      }
    }
  }

  // Atualiza o estado da planta
  update(agua, luz, nutrientes) {
    if (this.saude <= 0) {
      estadoJogo = "morto";
      return;
    }
    if (this.floresceu) { // Se já floresceu, apenas mantém o estado
        return;
    }

    let taxaCrescimento = 0;
    let danoSaude = 0;

    // --- Efeito da Água ---
    if (agua > 80) { // Muita água
      danoSaude += (agua - 80) * 0.1;
      taxaCrescimento -= (agua - 80) * 0.01;
    } else if (agua < 20) { // Pouca água
      danoSaude += (20 - agua) * 0.1;
      taxaCrescimento -= (20 - agua) * 0.01;
    } else { // Água ideal
      taxaCrescimento += 0.1;
    }

    // --- Efeito da Luz ---
    if (luz > 80) { // Muita luz
      danoSaude += (luz - 80) * 0.1;
      taxaCrescimento -= (luz - 80) * 0.01;
    } else if (luz < 20) { // Pouca luz
      danoSaude += (20 - luz) * 0.1;
      taxaCrescimento -= (20 - luz) * 0.01;
    } else { // Luz ideal
      taxaCrescimento += 0.1;
    }

    // --- Efeito dos Nutrientes ---
    if (nutrientes > 80) { // Muitos nutrientes
      danoSaude += (nutrientes - 80) * 0.1;
      taxaCrescimento -= (nutrientes - 80) * 0.01;
    } else if (nutrientes < 20) { // Poucos nutrientes
      danoSaude += (20 - nutrientes) * 0.1;
      taxaCrescimento -= (20 - nutrientes) * 0.01;
    } else { // Nutrientes ideais
      taxaCrescimento += 0.1;
    }

    // Atualiza a saúde (limitando entre 0 e 100)
    this.saude = constrain(this.saude - danoSaude, 0, 100);

    // Atualiza o crescimento
    if (this.saude > 20) { // Só cresce se a saúde for razoável
      this.altura += constrain(taxaCrescimento, -1, 2); // Limita a taxa de crescimento
      this.altura = constrain(this.altura, 5, height - 100); // Limita a altura máxima
      this.tempoCrescimento += taxaCrescimento; // Acumula tempo de crescimento
    }

    // Verifica se floresceu
    if (this.tempoCrescimento >= this.tempoMaxCrescimento && this.saude > 50 && !this.floresceu) {
      this.floresceu = true;
      estadoJogo = "floresceu";
    }
  }
}


// --- FUNÇÃO DE CONFIGURAÇÃO (SETUP) ---
function setup() {
  createCanvas(800, 600); // Cria uma tela maior
  rectMode(CENTER);
  textAlign(CENTER, CENTER);

  // Cria os sliders para controlar os fatores
  sliderAgua = createSlider(0, 100, 50); // Mín, Máx, Valor inicial
  sliderAgua.position(20, height - 80);
  sliderAgua.style('width', '200px');

  sliderLuz = createSlider(0, 100, 50);
  sliderLuz.position(20, height - 50);
  sliderLuz.style('width', '200px');

  sliderNutrientes = createSlider(0, 100, 50);
  sliderNutrientes.position(20, height - 20);
  sliderNutrientes.style('width', '200px');

  // Inicializa a planta
  planta = new Planta();
}


// --- FUNÇÃO DE DESENHO (DRAW) ---
function draw() {
  background(135, 206, 235); // Céu azul claro

  // Desenha o solo
  fill(139, 69, 19); // Marrom
  rect(width / 2, height - 25, width, 50);

  // --- Lógica do Jogo ---
  if (estadoJogo === "inicio") {
    exibirTelaInicio();
  } else if (estadoJogo === "jogando") {
    // Pega os valores dos sliders
    let aguaValor = sliderAgua.value();
    let luzValor = sliderLuz.value();
    let nutrientesValor = sliderNutrientes.value();

    planta.update(aguaValor, luzValor, nutrientesValor);
    planta.display();
    exibirInformacoes(aguaValor, luzValor, nutrientesValor);

  } else if (estadoJogo === "morto") {
    exibirTelaMorte();
  } else if (estadoJogo === "floresceu") {
      exibirTelaFloresceu();
  }
}

// --- FUNÇÕES AUXILIARES ---

function exibirTelaInicio() {
  fill(0);
  textSize(40);
  text("Cultivando o Futuro", width / 2, height / 2 - 50);
  textSize(20);
  text("Clique para Plantar a Semente", width / 2, height / 2 + 20);
  text("Controle Água, Luz e Nutrientes para fazê-la florescer!", width / 2, height / 2 + 50);

  // Esconde os sliders na tela de início
  sliderAgua.hide();
  sliderLuz.hide();
  sliderNutrientes.hide();
}

function exibirInformacoes(agua, luz, nutrientes) {
  fill(0);
  textSize(16);
  textAlign(LEFT);
  text("Água: " + agua + "%", sliderAgua.x + sliderAgua.width + 10, sliderAgua.y + 10);
  text("Luz: " + luz + "%", sliderLuz.x + sliderLuz.width + 10, sliderLuz.y + 10);
  text("Nutrientes: " + nutrientes + "%", sliderNutrientes.x + sliderNutrientes.width + 10, sliderNutrientes.y + 10);
  text("Saúde da Planta: " + floor(planta.saude) + "%", 20, height - 120);
  text("Progresso: " + floor(planta.tempoCrescimento / planta.tempoMaxCrescimento * 100) + "%", 20, height - 140);

  // Mostra os sliders durante o jogo
  sliderAgua.show();
  sliderLuz.show();
  sliderNutrientes.show();
}

function exibirTelaMorte() {
  fill(0);
  textSize(40);
  text("Sua planta morreu! :(", width / 2, height / 2 - 50);
  textSize(20);
  text("Ela não resistiu. Tente novamente!", width / 2, height / 2);
  text("Pressione 'R' para Recomeçar", width / 2, height / 2 + 30);

  // Esconde os sliders
  sliderAgua.hide();
  sliderLuz.hide();
  sliderNutrientes.hide();
}

function exibirTelaFloresceu() {
    fill(0);
    textSize(40);
    text("Parabéns! Salvamos mais uma planta!", width / 2, height / 2 - 50);
    textSize(20);
    text("Você cultivou o futuro com sucesso!", width / 2, height / 2);
    text("Pressione 'R' para Recomeçar", width / 2, height / 2 + 30);

    // Esconde os sliders
    sliderAgua.hide();
    sliderLuz.hide();
    sliderNutrientes.hide();
}

// --- Eventos do Mouse/Teclado ---
function mousePressed() {
  if (estadoJogo === "inicio") {
    estadoJogo = "jogando";
  }
}

function keyPressed() {
  if (keyCode === 82 && (estadoJogo === "morto" || estadoJogo === "floresceu")) { // Tecla 'R' (código 82)
    reiniciarJogo();
  }
}

function reiniciarJogo() {
  planta = new Planta(); // Cria uma nova planta
  sliderAgua.value(50); // Reseta os sliders para o valor inicial
  sliderLuz.value(50);
  sliderNutrientes.value(50);
  estadoJogo = "jogando"; // Volta para o estado de jogo
}